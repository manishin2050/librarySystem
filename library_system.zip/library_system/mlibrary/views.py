from django.shortcuts import render ,redirect
from datetime import datetime
from mlibrary.models import Subject,Book
from django.contrib import messages

# Create your views here.
# def index(request):
#     return render(request,"index.html")
def addBook(request):
    books={
         "books":Book.objects.all().values(),
    }
    if request.method=='POST':
        b_name=request.POST.get('b_name')
        Books=Book(b_name=b_name)
        Books.save()
        messages.success(request,'Book Added Susscussfully')
    return render(request,"addBook.html",books)
    # return HttpResponse(request,"jai ram ji")

def issueBook(request):
    subjects={
        'Subject':Subject.objects.all().values(),
        'books':Book.objects.all().values(),
        'totalBooks':Book.objects.all().count(),
        # 'commonBook':Book.objects.filter(b_name="Sanskrit").count(),

             }
    if request.method =='POST':
        name= request.POST.get('name')
        email= request.POST.get('email')
        subject= request.POST.get('subject')
        sub= request.POST.get('subject')
        phone= request.POST.get('phone')
        date= datetime.today()
        subject= Subject(name=name,email=email,phone=phone,subject=subject,date=date)
        subject.save()

        Book.objects.filter(b_name=f'{sub}')[0].delete()
        # print('==========================================================================================',a)
        messages.success(request,"Congrates you have a Book. Must Return under 30 days")
        subjects={
        'Subject':Subject.objects.all().values(),
        'books':Book.objects.all().values(),
        'totalBooks':Book.objects.all().count(),
        # 'no':Book.objects.all()
             }
        # return render(request,"issueBook.html",subjects)

    return render(request,"issueBook.html",subjects)

def append(request,B_id):
    books={
         "books":Book.objects.get(B_id=B_id).b_name
    }
    b_name=Book.objects.get(B_id=B_id).b_name
    quantity=Book.objects.get(B_id=B_id).quantity
    book=Book(B_id=B_id,b_name=b_name,quantity=quantity+1)
    book.save()
    return render(request,'append.html',books)

def delete(request,id):
        sub=Subject.objects.get(id=id).subject
        book=Book(b_name=sub)
        book.save()
        subject=Subject.objects.filter(id=id).delete()
        return redirect('/')
