from django.urls import path
from . import views

urlpatterns = [
    # path("", views.index, name="index"),
    path("addBook/", views.addBook, name="addBook"),
    path("delete/<int:id>", views.delete, name="delete"),
    path("addBook/append/<int:B_id>", views.append, name="append"),
    path("", views.issueBook, name="issueBook"),

]