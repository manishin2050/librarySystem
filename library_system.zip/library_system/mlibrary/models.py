from django.db import models

# Create your models here.
# this class about students
class Subject(models.Model):
    id=models.AutoField(primary_key=True)
    name=models.CharField(max_length=122,null=True)
    email=models.CharField(max_length=122,null=True)
    subject=models.CharField(max_length=122,null=True)
    phone=models.CharField(max_length=12,null=True)
    date=models.DateField()

    def __str__(self):
        return self.name

# this class in only for book name
class Book(models.Model):
    B_id=models.AutoField(primary_key=True)
    b_name=models.CharField(max_length=122,null=True)
    quantity=models.IntegerField(null=True,default=1)

    def __str__(self):
        return self.b_name